#ifdef _cplusplus
#if _cplusplus
extern "C" {
#endif /* _cplusplus */
#endif /* _cplusplus */





#include <stddef.h>
#include <stdlib.h>
#include <linux/kernel.h>


static ssize_t n_read;
static ssize_t n_write;
static ssize_t erropn;


typedef off_t b_tree_node;



#ifndef NULL
#define NULL ((void *)0)
#endif /* NULL */

#ifndef BOOL
#define BOOL int
#endif /* BOOL */


#ifndef MINIMUM_DEGREE
#define MINIMUM_DEGREE 8
#endif /* MINIMUM_DEGREE */

#ifndef CHAR
#define CHAR char
#endif /* CHAR */


#ifndef KEY_TYPE
#define KEY_TYPE int
#endif /* KEY_TYPE */


#ifndef TRUE
#define TRUE 1
#endif /* TRUE */


#ifndef FALSE
#define FALSE 0
#endif /* FALSE */



#ifndef _DISK_RDWR_H
#define _DISK_RDWR_H

#define B_TREE_NODE_WRITE_DISK(tree, node) \
	pwrite((tree)->fd, node, sizeof(BTreeNode), (node)->self)
		
	
#define B_TREE_NODE_READ_DISK(tree, node, offset) \
	pread((tree)->fd, node, sizeof(BTreeNode), offset)

#define B_TREE_WRITE_DISK(tree) \
	pwrite((tree)->fd, tree, sizeof(b_tree), 0)

#define B_TREE_READ_DISK(tree, fd) \
	pread(fd, tree, sizeof(b_tree), 0)

#endif /* _DISK_RDWR */






#ifdef _cplusplus 
#if _cplusplus 
}
#endif /* _cplusplus */
#endif /* _cplusplus */
